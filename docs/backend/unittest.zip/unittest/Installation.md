---
title: Installation
displayed-sidebar : backend
sidebar_position: 2

---
| Pros | Cons |
|------|------|
| Built into Python | More verbose compared to Pytest |
| Supports structured test cases | No built-in async support |
| Good for legacy projects | Less flexibility |
| Supports test discovery |