---
title: Installation
displayed-sidebar : backend
sidebar_position: 2

---

| Pros | Cons |
|------|------|
| Supports async API requests | Not a full-fledged testing framework |
| Works well for integration testing | Requires Pytest or Unittest for assertions |
| Can be used for load testing | Requires extra configuration |